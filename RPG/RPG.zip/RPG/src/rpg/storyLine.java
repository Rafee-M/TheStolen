//package rpg;
//import rpg.project.One;
////import static rpg.project.RPGProject.playerName;
//
//public class storyLine {
//    
//    
//    public void get1(){
//        One one = new One("Rafee");
//    }
//}
