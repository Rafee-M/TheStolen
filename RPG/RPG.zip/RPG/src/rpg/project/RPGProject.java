package rpg.project;

import java.util.Scanner;

public class RPGProject {
public static String playerName;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your name: ");
        playerName = scanner.nextLine();
        System.out.println();
        Four four = new Four(playerName, 3);
        Six six = new Six(playerName,7);
    }
    
}
