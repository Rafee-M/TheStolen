package rpg;

/**
 *
 * @author Rafee-M
 */

public class RPG {

    public static void main(String[] args) {

        StartingScreen stsc = new StartingScreen();
        stsc.setVisible(true);
    }

}
