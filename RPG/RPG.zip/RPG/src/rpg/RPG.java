package rpg;

import javax.swing.*;

public class RPG {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                createAndShowGUI();
            }
        });
    }
    
    private static void createAndShowGUI() {
        // Create and set up the frame
        JFrame frame = new JFrame("RPG Game");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        // Create a label to display some text
        JLabel label = new JLabel("Welcome to the RPG Game!");
        frame.getContentPane().add(label);
        
        // Display the frame
        frame.pack();
        frame.setVisible(true);
    }
}
